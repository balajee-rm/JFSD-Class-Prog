package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class CurrencyController {
	
	@Autowired
	Repository r;
	
	@GetMapping("/check")
	@ResponseBody
	public String fun1 () {
		return "working";
	}
	
	@GetMapping("/save/{from}/{to}/{rate}")
	@ResponseBody
	public String fun2 (@PathVariable("from") String from, @PathVariable("to") String to, @PathVariable("rate") double rate) {
		Currency c1 = new Currency();
		c1.setFrom(from);
		c1.setTo(to);
		c1.setRate(rate);
		r.save(c1);
		return "save successfull";
	}
	
	@GetMapping("/ret/{from}/{to}")
	@ResponseBody
	public Currency fun3 (@PathVariable("from") String from, @PathVariable("to") String to) {
		return r.findByFromAndTo(from, to);
	}
	
}
