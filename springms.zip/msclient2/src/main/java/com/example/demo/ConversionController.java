package com.example.demo;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

@Controller
public class ConversionController {
	@GetMapping("/calculate/{from}/{to}/{quantity}")
	@ResponseBody
	public Conversion convertCurrency(@PathVariable String from, @PathVariable String to,
			@PathVariable int quantity) {

		Map<String, String> uriVariables = new HashMap<>();
		uriVariables.put("from", from);
		uriVariables.put("to", to);

		ResponseEntity<Conversion> responseEntity = new RestTemplate().getForEntity(
				"http://localhost:8080/ret/{from}/{to}", Conversion.class,
				uriVariables);

		Conversion response = responseEntity.getBody();
		response.setQuantity(quantity);
		response.setTotal(response.getRate()*quantity);
		return response;
	}

}
