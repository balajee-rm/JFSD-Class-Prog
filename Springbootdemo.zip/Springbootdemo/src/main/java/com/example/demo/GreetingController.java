package com.example.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class GreetingController {
  Greeting g1=new Greeting();
  public static Map<Integer,Greeting> repo=new HashMap<>();
  @Autowired
  Repository r1;
  /*
  static
  {
	  Greeting g1=new Greeting();
	    g1.setId(33);
	    g1.setName("Jayanth");
	    Greeting g2=new Greeting();
	    g2.setId(11);
	    g2.setName("KT");
	    //repo.put(g1.getId(), g1);
	    //repo.put(g2.getId(), g2);
	    try {
	    	r1.save(g1);
	    	r1.save(g2);
	    }
	    catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
  }
  */
  //@RequestMapping(value="/greeting/{name}",method=RequestMethod.GET)
  @GetMapping("/greeting")
  @ResponseBody
  public List<Greeting> fun1 (@RequestParam (value="name",defaultValue="world") String name)
  {
	  List<Greeting> l=new ArrayList<>();
    //g1.setId(1);
    //g1.setName(name);
	  Greeting g1=new Greeting();
	    g1.setId(33);
	    g1.setName("Jayanth");
	    Greeting g2=new Greeting();
	    g2.setId(11);
	    g2.setName("KT");
	    //repo.put(g1.getId(), g1);
	    //repo.put(g2.getId(), g2);
	    try {
	    	r1.save(g1);
	    	r1.save(g2);
	    }
	    catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
    r1.findAll().forEach(l::add);
    return l;
    
  }
  
  @GetMapping("/insertform")
  public String insertform(Model m)
  {
	  m.addAttribute("command",new Greeting());
	  return "index";
  }
  
  @ResponseBody
  @PostMapping("/insert")
  public Map insert(@ModelAttribute("g") Greeting g)
  {
	  repo.put(g.getId(), g);
	  return repo;
  }
  
}