//package com.example.demo;
//
//import java.util.HashMap;
//import java.util.Map;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//public class HelloControllerTest {
//	@Autowired
//	Greeting g1;
//	//@RequestMapping(value="/greeting/{name}",method=RequestMethod.GET)
//	//@GetMapping("/greeting")
//	/*public Greeting fun1(@RequestParam (value="name",defaultValue="world") String name) throws Exception {
//		g1.setId(1);
//		g1.setName("name");
//		return g1;
//	}*/
//	  /*public Greeting fun1 (@PathVariable String name)
//	  {
//	    g1.setId(1);
//	    g1.setName(name);
//	    return g1;
//	    
//	  }*/
//	Map<Integer,Greeting> k=new HashMap<>();
//	  public HelloControllerTest()
//	  {
//	    Greeting g1=new Greeting();
//	    g1.setId(33);
//	    g1.setName("Jayanth");
//	    Greeting g2=new Greeting();
//	    g2.setId(11);
//	    g2.setName("KT");
//	    k.put(g1.getId(), g1);
//	    k.put(g2.getId(), g2);
//	  }
//	  @PostMapping("/insert")
//	  public Greeting insert(@RequestBody Greeting g)
//	  {
//	    k.put(g.getId(),g);
//	    return g;
//	  }
//	  @GetMapping("/disp")
//	  public Map<Integer, Greeting> display()
//	  {
//	    return k;
//	  }
//
//	  //@RequestMapping(value="/greeting",method=RequestMethod.GET)
//	  //@GetMapping("/greeting/{id}/{name}")
//	   @GetMapping("/greeting")
//	   //@RequestMapping(value="/greeting/{name}",method=RequestMethod.GET)
//	    public Greeting fun1 (@RequestParam (value="name",defaultValue="world")String name)
//	    {
//	      return  k.get(44);
//	    }
//	
//}
